
class DNAAnalyser:

    REPORT_MAPPING_FILENAME = 'codon.tsv'

    def __init__(self):
        pass

    @staticmethod
    def clean_strands(filename):
        with open(filename) as f:
            lines = f.readlines()
            
        lines=[each for each in lines if  len(each)> 10 and len(each) < 100 and  len(each) != 0]
        new_lines=[]
        for each in lines:
            if len(set(each)-set("ATGC")) == 0:
                new_lines.append(each)
        
        cleaned_list = new_lines
        return cleaned_list

    def create_strands(self, cleaned_list):

    out="a"
    
    for count in range(len(cleaned_list)):
                
    
        try:
            if ( cleaned_list[count][-3:] == cleaned_list[count+1][:3]):
               if out == "a":
                    out=cleaned_list[count]
                out = out + cleaned_list[count+1][3:]
                
        except:
            if ( cleaned_list[count][-3:] == cleaned_list[0][:3]):
                out=out+cleaned_list[0][:3]
                
    result = out
    return result

    def get_amino_acids_report(self, dna_sequence):
        
        
        filename="codon.tsv"
        with open(filename) as f:
           lines = f.readlines()
    
        keys=[each[:-2].split("\t")[0] for each in lines]
        values=[each[:-2].split("\t")[1] for each in lines]
        dictionary=dict(zip(keys,values))
                
        data=[out[each:each+3] for each in range(len(out)-3) ]
        new_data = [dictionary[each]  for each in data ]
        
        keys=set(new_data)
        values=[0]*len(set(new_data))
        new_dict=dict(zip(keys,values))
        
        for each in new_data:
            new_dict[each]=new_dict[each]+1
            
        report = new_dict
        return report


